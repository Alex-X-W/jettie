def woof():
  print('I am a Shiba, and I woof! Woof!')